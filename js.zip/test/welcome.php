<html>
<body>
<?php
$name = $_POST["name"];
$email = $_POST["email"];
echo "<p>Hi my name is Gaurav nd this script is working</p>";
echo $name;
echo "and the email is", $email; 
?>
</body>
</html>
